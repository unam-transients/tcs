See doc/README.txt and the other files there for information.
